const fs = require("fs");
const path = require("path");

const solutions = JSON.parse(
  fs.readFileSync(`../static/solution/solutions.json`).toString()
);

// basic 1 - 36
// topic 37-72
// advanced 73-91
let content = "";

for (let day = 1; day <= 36; day++) {
  content += `- [【Day ${day}】${solutions[day].title}](./d${day}.md)\n`;
}

fs.writeFileSync(`solution/basic/summary.md`, content);

content = "";

for (let day = 37; day <= 72; day++) {
  content += `- [【Day ${day}】${solutions[day].title}](./d${day}.md)\n`;
}

fs.writeFileSync(`solution/topic/summary.md`, content);

content = "";

for (let day = 73; day <= 91; day++) {
  content += `- [【Day ${day}】${solutions[day].title}](./d${day}.md)\n`;
}

fs.writeFileSync(`solution/advanced/summary.md`, content);

// for (let day = 64; day >= 29; day--) {
//   fs.renameSync(
//     path.resolve(__dirname, `../solution/topic/d${day}.md`),
//     path.resolve(__dirname, `../solution/topic/d${day + 8}.md`)
//   );
// }

// for (let day = 83; day >= 65; day--) {
//   fs.renameSync(
//     path.resolve(__dirname, `../solution/advanced/d${day}.md`),
//     path.resolve(__dirname, `../solution/advanced/d${day + 8}.md`)
//   );
// }
